// login popup
var login = document.getElementById('loginPopup');
var btn = document.getElementById("loginBtn");
var close = document.getElementsByClassName("close")[0];

btn.onclick = function() {
  login.style.display = "block";
}

close.onclick = function() {
  login.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == login) {
      login.style.display = "none";
  }
}


// slide menu bar
// var navStyle = document.querySelector(".navigation");
// var openNav = document.getElementById("navMenu");
// var closeNav = document.getElementsByClassName("close-nav")[0];
// console.log(navStyle.style.width);
// openNav.onclick = function() {
//   navStyle.style.margin-left = "0";
// }
//
// closeNav.onclick = function() {
//   navStyle.style.width = "0";
// }
